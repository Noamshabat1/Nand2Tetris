Instructions:
for the SysTestNew + OutputTestNew - put your class in the folder, and compile it using the jack compiler. then load the folder in the VMemulator.
for SysTestNew  - choose the error you want to be printed in Main.jack (uncomment the error) - make sure the error is printed and 
					that there isnt a black square printed
for OutputTestNew - follow the instructions on the screen (make sure that is the screen mode you are on in the VMemulator)
for MathTestNew - there is a .tst file in the folder.
					

Tests:

1. SysTestNew - checks the correct error codes are printed out and that the
				program halts.
				to check the error - uncomment the error in Main.jack that you want to check,
				make sure a rectangle is not printed on the screen after.
				Make sure you only load your Sys class, and not the other files
2. OutputTestNew - checks the Output Class. checks the cursor functionality, 
					and the backspace and println. The instructions are printed to the screen.
3. MathTestNew - checks a few more מקרי קצה. there is a .tst file
